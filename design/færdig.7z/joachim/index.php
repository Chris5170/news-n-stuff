<!DOCTYPE html>
<html>
<head>
	<title>Joachim</title>
        <link href="https://fonts.googleapis.com/css?family=Fredericka+the+Great|Open+Sans" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header class="header_container">
        <div class="header">
            <div class="logo">
                <img src="https://meemiq.com/wp-content/uploads/2018/10/Bizmiq_Hvid-%C3%94%C3%87%C3%B4-transparent.png" alt="Meemiq" height="70" width="70">
            </div>
            <div class="nav">
                <a href="#home">Global</a>
                <a href="#contact">Sports</a>
                <a href="#about">Lifestyle</a>
                <a href="#about">Business</a>
            </div>
        </div>
    </header>
    <section class="body-front">
    </section>
	<section class="news_container">
		<div class="news">  
		  <a href="#"><!-- Link til artikel -->
		      <h3>Titel</h3>
		      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
		  </a>
		</div>
		<div class="news">  
		  <a href="#"><!-- Link til artikel -->
		      <h3>Titel</h3>
		      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
		  </a>
		</div>
		<div class="news">  
		  <a href="#"><!-- Link til artikel -->
		      <h3>Titel</h3>
		      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
		  </a>
		</div>
		<div class="news">  
		  <a href="#"><!-- Link til artikel -->
		      <h3>Titel</h3>
		      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
		  </a>
		</div>
                <div class="news">  
		  <a href="#"><!-- Link til artikel -->
		      <h3>Titel</h3>
		      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
		  </a>
		</div>
        <div class="news">  
		  <a href="#"><!-- Link til artikel -->
		      <h3>Titel</h3>
		      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
		  </a>
		</div>
        <div class="news">  
		  <a href="#"><!-- Link til artikel -->
		      <h3>Titel</h3>
		      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
		  </a>
		</div>
        <div class="news">  
		  <a href="#"><!-- Link til artikel -->
		      <h3>Titel</h3>
		      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
		  </a>
		</div>
        <div class="news">  
		  <a href="#"><!-- Link til artikel -->
		      <h3>Titel</h3>
		      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
		  </a>
		</div>
        <div class="news">  
		  <a href="#"><!-- Link til artikel -->
		      <h3>Titel</h3>
		      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
		  </a>
		</div>
        <div class="news">  
		  <a href="#"><!-- Link til artikel -->
		      <h3>Titel</h3>
		      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
		  </a>
		</div>
        <div class="news">  
		  <a href="#"><!-- Link til artikel -->
		      <h3>Titel</h3>
		      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
		  </a>
		</div>
	</section>
     <footer class="footer-container">
        <div class="footer">
            <div class="some">
                <img src="https://cdn0.iconfinder.com/data/icons/shift-free/32/Facebook-512.png" alt="Facebook" height="32" width="32">
                <img src="https://cdn1.iconfinder.com/data/icons/social-media-icon-1/112/instagram-512.png" alt="Instagram" height="32" width="32">
                <img src="https://cdn3.iconfinder.com/data/icons/capsocial-round/500/linkedin-512.png" alt="Linkedin" height="32" width="32">
                <img src="https://cdn0.iconfinder.com/data/icons/social-media-2091/100/social-08-512.png" alt="Snapchat" height="32" width="32">
            </div>
        </div>
    </footer>
</body>
</html>
